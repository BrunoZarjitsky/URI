saida = []
for i in range(100):
    entrada = float(input())
    if entrada <= 10:
        print ("A[%i] = %.1f" %(i, entrada))